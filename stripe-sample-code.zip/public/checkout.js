// This is your test publishable API key.
const stripe = Stripe("pk_test_51S1E724OFXg8iiC49TxV0fLxHP1jtsdefeRiklMUinCYwl3HxHypAMVMZ4dcK6W9u2a9oEzD8GK7pcQmnKEI1Z5z008wT3L78v");

initialize();

// Create a Checkout Session
async function initialize() {
  const fetchClientSecret = async () => {
    const response = await fetch("/create-checkout-session", {
      method: "POST",
    });
    const { clientSecret } = await response.json();
    return clientSecret;
  };

  const checkout = await stripe.initEmbeddedCheckout({
    fetchClientSecret,
  });

  // Mount Checkout
  checkout.mount('#checkout');
}